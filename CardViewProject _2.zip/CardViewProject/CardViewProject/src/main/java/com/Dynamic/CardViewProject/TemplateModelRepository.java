package com.Dynamic.CardViewProject;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TemplateModelRepository extends JpaRepository<TemplateModel,Integer> {

}
