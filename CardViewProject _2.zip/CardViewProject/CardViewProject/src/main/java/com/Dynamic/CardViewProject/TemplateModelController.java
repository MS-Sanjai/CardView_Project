package com.Dynamic.CardViewProject;

import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller

public class TemplateModelController {
	
	
	
	 private final TemplateModelRepository templateModelRepository;

	    @Autowired
	    public TemplateModelController(TemplateModelRepository templateModelRepository) {
	        this.templateModelRepository = templateModelRepository;
	    }

	    @GetMapping("/")
	    public String listViewForm(Model model) {
	        List<TemplateModel> templateModels = templateModelRepository.findAll();
	     // Sort the list of templateModels in ascending order by name
	        templateModels.sort(Comparator.comparing(TemplateModel::getName));
	        model.addAttribute("users", templateModels);
	        return "index"; // Return "index" as the view name
	    }

	   
	    
	    

}
